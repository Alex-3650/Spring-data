package soft_uni.mvc.services;

import jakarta.validation.ConstraintViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;
import soft_uni.mvc.dto.imports.ImportCompanyDto;
import soft_uni.mvc.dto.imports.ImportRootCompanyDto;
import soft_uni.mvc.repositories.CompanyRepository;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

@Validated
@Service
public class ImportCompanyServiceImpl implements ImportCompanyService {

    public static final Path IMPORT_DATA_PATH = Path.of("src/main/resources/files/xmls/companies.xml");
    private final CompanyService companyService;
    private final CompanyRepository companyRepository;
    private final Unmarshaller importParser;

    public ImportCompanyServiceImpl(CompanyService companyService, CompanyRepository companyRepository) throws JAXBException {
        this.companyService = companyService;

        this.companyRepository = companyRepository;
        JAXBContext jaxbContext = JAXBContext.newInstance(ImportRootCompanyDto.class);
        this.importParser = jaxbContext.createUnmarshaller();
    }

    public boolean isDataImported(){
        return this.companyRepository.count() > 0;
    }

    public String getXmlFile() throws IOException {
        List<String> lines = Files.readAllLines(IMPORT_DATA_PATH);
        return String.join("\n", lines);
    }

    @Override
    @Transactional
    public int importCompaniesData() throws IOException, JAXBException {
        ImportRootCompanyDto parsed = (ImportRootCompanyDto) this.importParser.unmarshal(Files.newInputStream(IMPORT_DATA_PATH));
        List<ImportCompanyDto> toImport = parsed.getCompanies();
        int successfullyImportedCount = 0;

        for (ImportCompanyDto company : toImport){

            try {
                boolean success = this.companyService.create(company);
                if (success) successfullyImportedCount++;
            } catch (ConstraintViolationException e) {

            }

        }
        return successfullyImportedCount;
    }

}
