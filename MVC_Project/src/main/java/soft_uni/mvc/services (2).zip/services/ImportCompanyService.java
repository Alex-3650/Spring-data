package soft_uni.mvc.services;

import javax.xml.bind.JAXBException;
import java.io.IOException;

public interface ImportCompanyService {

    boolean isDataImported();

    String getXmlFile() throws IOException;

    int importCompaniesData() throws IOException, JAXBException;


}
