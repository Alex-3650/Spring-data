package soft_uni.mvc.services;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.springframework.validation.annotation.Validated;
import soft_uni.mvc.dto.imports.ImportCompanyDto;

@Validated
public interface CompanyService {

    boolean create(@NotNull @Valid ImportCompanyDto company);
}
