package soft_uni.mvc.services;

import jakarta.validation.ConstraintViolationException;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import soft_uni.mvc.dto.imports.ImportCompanyDto;
import soft_uni.mvc.entities.Company;
import soft_uni.mvc.repositories.CompanyRepository;

@Service
public class CompanyServiceImpl implements CompanyService {

    private final CompanyRepository companyRepository;
    private final ModelMapper modelMapper;

    public CompanyServiceImpl(CompanyRepository companyRepository, ModelMapper modelMapper) {
        this.companyRepository = companyRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public boolean create(ImportCompanyDto company) {
        try {
            Company companyMapped = this.modelMapper.map(company, Company.class);
            this.companyRepository.save(companyMapped);
            return true;
        } catch (Exception e) {
            return false;
        }

    }
}
