package soft_uni.gameservice.services;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;
import soft_uni.gameservice.dtos.Game.GameInputDto;
import soft_uni.gameservice.dtos.Game.GameMinifiedDto;
import soft_uni.gameservice.entities.Game;
import soft_uni.gameservice.repositories.GameRepository;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Service
public class GameServiceImpl implements GameService {

    private final GameRepository gameRepository;
    private final ModelMapper modelMapper;


    @Autowired
    public GameServiceImpl(GameRepository gameRepository, ModelMapper modelMapper) {
        this.gameRepository = gameRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public GameMinifiedDto create(GameInputDto dto) {
        Game game = modelMapper.map(dto, Game.class);

        game.setReleaseDate(LocalDate.now());
        this.gameRepository.save(game);

        return this.modelMapper.map(game, GameMinifiedDto.class);
    }
}
