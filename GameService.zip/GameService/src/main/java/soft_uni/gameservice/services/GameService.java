package soft_uni.gameservice.services;

import jakarta.validation.Valid;
import org.springframework.validation.annotation.Validated;
import soft_uni.gameservice.dtos.Game.GameInputDto;
import soft_uni.gameservice.dtos.Game.GameMinifiedDto;

@Validated
public interface GameService {

    GameMinifiedDto create(@Valid GameInputDto game);
}
