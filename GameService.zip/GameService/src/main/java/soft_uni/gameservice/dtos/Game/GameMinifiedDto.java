package soft_uni.gameservice.dtos.Game;

import java.math.BigDecimal;

public class GameMinifiedDto {

    private long id;
    private String title;
    private BigDecimal price;

    public GameMinifiedDto(long id, String title, BigDecimal price) {
        this.id = id;
        this.title = title;
        this.price = price;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }
}
