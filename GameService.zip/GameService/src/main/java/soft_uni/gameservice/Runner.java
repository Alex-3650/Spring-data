package soft_uni.gameservice;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;
import soft_uni.gameservice.dtos.Game.GameInputDto;
import soft_uni.gameservice.dtos.Game.GameMinifiedDto;
import soft_uni.gameservice.dtos.User.UserDto;
import soft_uni.gameservice.dtos.User.UserLoginDto;
import soft_uni.gameservice.dtos.User.UserRegisterDto;
import soft_uni.gameservice.services.GameServiceImpl;
import soft_uni.gameservice.services.UserServiceImpl;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.function.Function;

@Component
public class Runner implements CommandLineRunner {
    private final UserServiceImpl userService;
    private final GameServiceImpl gameService;
    private final BCryptPasswordEncoder encoder;

    private UserDto currentUser;

    @Autowired
    public Runner(UserServiceImpl userService, GameServiceImpl gameService, BCryptPasswordEncoder bCryptPasswordEncoder) {
        this.userService = userService;
        this.gameService = gameService;
        this.encoder = bCryptPasswordEncoder;
    }


    @Override
    public void run(String... args) throws Exception {
      ensureFirstAdmin();

      Scanner scanner = new Scanner(System.in);
      Map<String, Function<String[],String>> commands = new HashMap<>();
      commands.put("RegisterUser",this::register);
      commands.put("LoginUser",this::login);
      commands.put("WhoAmI",this::whoAmI);
      commands.put("Logout",this::logout);
      commands.put("AddGame",this::addGame);

      String input = scanner.nextLine();
      while (!input.equals("Exit")) {
          String [] data = input.split("\\|");
          String command = data[0];
          Function<String[],String> function = commands.get(command);
          String output = execute(function, data);
          System.out.println(output);
          input = scanner.nextLine();
      }

    }



    private String whoAmI(String[] data) {
       ensureAuthenticated();
       return "You are logged in as \"%s\" with ID %d"
               .formatted(this.currentUser.getEmail(), this.currentUser.getId()) ;
    }


    private String register(String []data) {
        ensureAnonymous();
        UserRegisterDto userRegisterDto = new UserRegisterDto(data[1],data[2],data[3]);
        UserDto createdUser = this.userService.register(userRegisterDto);

        return "User \"%s\" with ID %d was registered successfully".formatted(createdUser.getEmail(),createdUser.getId());
    }

    private String login(String []data) {
        ensureAnonymous();
        UserLoginDto userLoginDto = new UserLoginDto(data[1],data[2]);
        UserDto loginUser = this.userService.login(userLoginDto);
        if (loginUser == null) {
            return "Invalid username or password";
        }
        this.currentUser = loginUser;
        return "User \"%s\" with ID %d was logged in successfully".formatted(loginUser.getEmail(),loginUser.getId());
    }

    private String logout(String []data) {
        this.ensureAuthenticated();
        this.currentUser = null;
        return "You logged out successfully";
    }

    private String addGame(String[] data) {
     this.ensureAdmin();

        GameInputDto gameInputDto = new GameInputDto(data[1],data[2],data[3], new BigDecimal(data[4]),data[5]);
        GameMinifiedDto gameMinifiedDto = this.gameService.create(gameInputDto);

        return "Game %s with ID %d was created successfully!".formatted(gameMinifiedDto.getTitle(),gameMinifiedDto.getId());
    }


    //HELPER METHODS
    private void ensureAuthenticated(){
        if (this.currentUser == null)
            throw new IllegalArgumentException("You are not logged in.Please, log in first.");
    }
    private void ensureAdmin(){
        this.ensureAuthenticated();
        if (!this.currentUser.getAdmin()) {
            throw new IllegalArgumentException("You are not admin.Please,contact your administrator.");
        }
    }

    private void ensureAnonymous(){
          if (this.currentUser != null)
              throw new IllegalArgumentException("You are already logged in.Please,log out first.");
    }

    private static String execute(Function<String[], String> function, String[] data) {

        if (function == null) {
            return "Invalid command";
        } else {
            try {
                return function.apply(data);
            } catch (Exception e) {
                return "ERROR!!! " + e.getMessage();
            }
        }
    }

    private void ensureFirstAdmin() {
        UserRegisterDto admin = new UserRegisterDto(
                "gameStore@gmail.com",
                "123456",
                "Ivan Peshev");
        admin.setPassword(encoder.encode(admin.getPassword()));

      UserDto userDto = userService.ensureAdmin(admin);

        if (userDto!=null) {
            System.out.printf("Admin registered with ID %d\n",userDto.getId());
        }else {
            System.out.println("Admin have already registered ");
        }
    }
}
