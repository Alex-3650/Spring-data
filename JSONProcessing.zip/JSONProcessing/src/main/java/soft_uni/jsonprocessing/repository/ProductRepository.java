package soft_uni.jsonprocessing.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import soft_uni.jsonprocessing.entities.Product;

public interface ProductRepository extends JpaRepository<Product, Long> {
}
