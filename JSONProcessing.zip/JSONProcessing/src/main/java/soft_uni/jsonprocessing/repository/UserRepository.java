package soft_uni.jsonprocessing.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import soft_uni.jsonprocessing.entities.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
}
