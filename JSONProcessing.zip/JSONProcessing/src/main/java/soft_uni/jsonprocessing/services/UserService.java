package soft_uni.jsonprocessing.services;

import com.google.gson.Gson;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;
import soft_uni.jsonprocessing.dtos.UserImportDto;
import soft_uni.jsonprocessing.entities.User;
import soft_uni.jsonprocessing.repository.UserRepository;
import tools.jackson.databind.introspect.DefaultAccessorNamingStrategy;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Optional;
import java.util.Random;

@Service
public class UserService {
//private final UserRepository userRepository;
private final UserRepository userRepository;
private final Gson gson;
private final ModelMapper modelMapper;

    public UserService(UserRepository userRepository, Gson gson, ModelMapper modelMapper) {
        this.userRepository = userRepository;
        this.gson = gson;
        this.modelMapper = modelMapper;
    }

    //public UserService(UserRepository userRepository) {}
    public void importData() throws IOException {
        Path path = Path.of("C:\\Users\\georg\\Spring_Data\\JSONProcessing\\src\\main\\resources\\json_files\\users.json");
        List<String> lines = Files.readAllLines(path);
        UserImportDto[] fromJson = gson.fromJson(String.join("", lines), UserImportDto[].class);
        for (UserImportDto userDto : fromJson) {
            if (userDto.getLastName() == null || userDto.getLastName().length() < 3) {
                System.err.println("User lastName is invalid!");
                continue;
            }
            User user = modelMapper.map(userDto, User.class);
            userRepository.save(user);
        }
        //Read JSON -> DTO
        //Validate
        //DTO ->ENTITY
        //Persist

    }

    public User getRandomUser() {
        long count = userRepository.count();

        if (count == 0) return null;
        Random random = new Random();
        long id = random.nextLong(1, count + 1);

        while (true) {
            Optional<User> byId = this.userRepository.findById(id);

            if (byId.isPresent()) {
                return byId.get();
            }

            id = random.nextLong(1, count + 1);
        }

    }
}
