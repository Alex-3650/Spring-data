package soft_uni.booksystem.service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.stereotype.Service;
import soft_uni.booksystem.dto.BookTitleView;
import soft_uni.booksystem.dto.BooksByGeorgePowellView;
import soft_uni.booksystem.entity.Book;
import soft_uni.booksystem.repository.BookRepository;

import java.time.LocalDate;
import java.util.List;

@Service
public class BookService {
    private final BookRepository bookRepository;


    @Autowired
    public BookService(BookRepository bookRepository, LocalContainerEntityManagerFactoryBean localContainerEntityManagerFactoryBean) {
        this.bookRepository = bookRepository;

    }

    public List<Book> findAllBooksAfter2000() {
      return  bookRepository.findAllByReleaseDateAfter(LocalDate.of(2000,12,31));
    }

    public List<BookTitleView> findAllBookTitlesByReleaseDateAfter2000() {
        return bookRepository.findAllTitlesByReleaseDateAfter(LocalDate.of(2000,12,31));
    }

    public List<BooksByGeorgePowellView> findAllBooksByGeorgePowellOrderByReleaseDateDescAndByTitleAsc() {
       return bookRepository.findAllBooksByGeorgePowellOrderByReleaseDateDescAndByTitleAsc("George", "Powell");
    }


}
