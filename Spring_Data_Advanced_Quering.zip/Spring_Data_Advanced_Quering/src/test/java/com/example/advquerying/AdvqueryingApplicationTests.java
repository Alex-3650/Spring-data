package com.example.advquerying;



@SpringBootTest
class AdvqueryingApplicationTests {

    @Test
    void contextLoads() {
    }

}
