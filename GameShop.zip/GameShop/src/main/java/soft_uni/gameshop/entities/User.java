package soft_uni.gameshop.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "users")
public class User extends BaseEntity{

  @NotNull(message = "Email cannot be null")
  @NotBlank(message = "Email cannot be empty")
  @Email(message = "Please provide a valid email address")
  @Column(unique=true,nullable=false,name = "email")
  private String email;

  @Column(nullable=false,name = "password")
  private String password;

  @Column(name = "fullName")
  private String fullName;

  @Column(nullable=false,name = "isAdmin")
  private Boolean isAdmin;

}
